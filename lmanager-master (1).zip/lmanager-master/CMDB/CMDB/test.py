#!/usr/bin/env python
import sys
sys.path.append("../app/backend")
from configapi import *
xiaoluo = dbconfig()

